package com.example.ch9app

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.pow

class MainActivity : AppCompatActivity() {

    // 宣告UI元件
    private lateinit var edAge: EditText
    private lateinit var edHeight: EditText
    private lateinit var edWeight: EditText
    private lateinit var btnCalculate: Button
    private lateinit var tvCalories: TextView
    private lateinit var tvProtein: TextView
    private lateinit var tvCarbs: TextView
    private lateinit var tvFat: TextView
    private lateinit var btnMale: RadioButton
    private lateinit var btnFemale: RadioButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 初始化UI元件
        edAge = findViewById(R.id.edAge)
        edHeight = findViewById(R.id.edHeight)
        edWeight = findViewById(R.id.edWeight)
        btnCalculate = findViewById(R.id.btnCalculate)
        tvCalories = findViewById(R.id.tvCalories)
        tvProtein = findViewById(R.id.tvProtein)
        tvCarbs = findViewById(R.id.tvCarbs)
        tvFat = findViewById(R.id.tvFat)
        btnMale = findViewById(R.id.btnboy)
        btnFemale = findViewById(R.id.btngirl)

        // 設置計算按鈕點擊事件
        btnCalculate.setOnClickListener {
            calculateDietNeeds()
        }
    }

    private fun calculateDietNeeds() {
        // 檢查輸入是否為空
        if (edAge.text.isEmpty() || edHeight.text.isEmpty() || edWeight.text.isEmpty()) {
            Toast.makeText(this, "請填寫所有欄位", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            // 獲取輸入值
            val age = edAge.text.toString().toInt()
            val height = edHeight.text.toString().toDouble()
            val weight = edWeight.text.toString().toDouble()
            val isMale = btnMale.isChecked

            // 計算基礎代謝率(BMR)
            val bmr = if (isMale) {
                // 男性BMR計算公式 (Harris-Benedict方程)
                88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age)
            } else {
                // 女性BMR計算公式
                447.593 + (9.247 * weight) + (3.098 * height) - (4.330 * age)
            }

            // 計算每日總熱量需求 (假設適中活動水平，乘以1.55)
            val calories = (bmr * 1.55).toInt()

            // 計算巨量營養素的建議攝取量
            // 蛋白質: 體重(kg) * 1.6g (適中運動者)
            val protein = (weight * 1.6).toInt()

            // 脂肪: 總熱量的25%
            val fat = (calories * 0.25 / 9).toInt()

            // 碳水化合物: 剩餘熱量
            val carbs = ((calories - protein * 4 - fat * 9) / 4).toInt()

            // 顯示結果
            tvCalories.text = calories.toString() + " 大卡"
            tvProtein.text = protein.toString() + " 克"
            tvCarbs.text = carbs.toString() + " 克"
            tvFat.text = fat.toString() + " 克"

        } catch (e: Exception) {
            Toast.makeText(this, "計算錯誤，請檢查輸入值", Toast.LENGTH_SHORT).show()
        }
    }
}